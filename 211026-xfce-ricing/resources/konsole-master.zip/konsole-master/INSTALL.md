### [Konsole](https://konsole.kde.org/)

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/konsole/archive/master.zip) option and unzip them.

#### Activating theme

1.  Copy `Dracula.colorscheme` to `~/.local/share/konsole`
2.  Go to _Konsole > Settings > Edit Current Profile… > Appearance_ tab
3.  Select the _Dracula_ scheme from the _Color Schemes & Background…_ pane
