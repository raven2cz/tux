### [kitty](https://sw.kovidgoyal.net/kitty/)

#### Install

Download using the [GitHub .zip download](https://github.com/dracula/kitty/archive/master.zip) option

```
cp dracula.conf diff.conf ~/.config/kitty/
echo "include dracula.conf" >> ~/.config/kitty/kitty.conf
```

Then reload kitty for the config to take affect.

Alternatively copy paste `dracula.conf` directly into `kitty.conf`.
